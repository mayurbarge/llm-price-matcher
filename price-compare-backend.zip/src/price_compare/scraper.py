"""Crawls one platform's search page with crawl4ai and returns up to
`max_items` products as plain dicts.

Kept deliberately simple, with no custom JS:

- Loading more results uses crawl4ai's own built-in page-scan
  (scan_full_page + scroll_delay + max_scroll_steps) instead of a
  hand-rolled scroll loop. It already stops itself once a scroll step
  doesn't reveal a taller page; MAX_SCROLL_STEPS is just a bound on how
  long it's allowed to keep trying.
- Limiting to `max_items` products happens in the extraction prompt itself
  (see models.build_extraction_instruction) -- the scraper doesn't need to
  inspect the page to know when "enough" has loaded, since a few scrolls
  is already more than enough content for a 20-item extraction, and the
  final slice below is just a safety net.
- wait_until="load" rather than "networkidle": some sites keep a
  background connection alive indefinitely (analytics, polling), so
  networkidle can hang until the page's own timeout kills the crawl.
  "load" is the standard, reliable "page is ready" signal instead.
"""

import json
import logging
import time

from crawl4ai import (
    AsyncWebCrawler,
    BrowserConfig,
    CacheMode,
    CrawlerRunConfig,
    LLMConfig,
    LLMExtractionStrategy,
)

from .config import EXTRACTION_LLM_API_KEY, EXTRACTION_LLM_PROVIDER, PlatformConfig
from .models import Product, build_extraction_instruction

logger = logging.getLogger(__name__)

MAX_SCROLL_STEPS = 5


class PlatformCrawlError(Exception):
    """Raised when a platform's page can't be crawled, or its content can't be parsed."""


def _build_browser_config(platform: PlatformConfig, headless: bool) -> BrowserConfig:
    return BrowserConfig(
        headless=headless,
        browser_type="undetected",  # crawl4ai's stealth Chromium (patchright-based)
        viewport_width=1280,
        viewport_height=2000,
        cookies=platform.build_browser_cookies(),
    )


def _build_extraction_strategy(max_items: int, verbose: bool) -> LLMExtractionStrategy:
    return LLMExtractionStrategy(
        llm_config=LLMConfig(provider=EXTRACTION_LLM_PROVIDER, api_token=EXTRACTION_LLM_API_KEY),
        schema=Product.model_json_schema(),
        extraction_type="schema",
        instruction=build_extraction_instruction(max_items),
        input_format="html",  # keeps name/price spatially paired better than markdown for dense grids
        verbose=verbose,
    )


def _build_run_config(platform: PlatformConfig, max_items: int, verbose: bool) -> CrawlerRunConfig:
    return CrawlerRunConfig(
        cache_mode=CacheMode.BYPASS,  # prices change constantly -- never serve a stale cache
        wait_until="load",
        scan_full_page=platform.requires_scroll_to_load_more_results,
        scroll_delay=platform.scroll_delay_seconds,
        max_scroll_steps=MAX_SCROLL_STEPS,
        extraction_strategy=_build_extraction_strategy(max_items, verbose),
        page_timeout=platform.page_load_timeout_ms,
        verbose=verbose,
    )


def _parse_extracted_products(raw_extracted_content: str, platform: PlatformConfig) -> list[dict]:
    try:
        parsed_content = json.loads(raw_extracted_content)
    except (TypeError, json.JSONDecodeError) as exc:
        raise PlatformCrawlError(f"{platform.label} extraction returned unparseable content") from exc

    products = parsed_content if isinstance(parsed_content, list) else [parsed_content]
    for product in products:
        product["platform"] = platform.key
    return products


async def crawl_platform(
    platform: PlatformConfig,
    search_query: str,
    headless: bool,
    max_items: int,
    verbose: bool = False,
) -> list[dict]:
    search_url = platform.build_search_url(search_query)
    browser_config = _build_browser_config(platform, headless)
    run_config = _build_run_config(platform, max_items, verbose)

    logger.info("[%s] sending request | url=%s max_items=%d", platform.label, search_url, max_items)

    started_at = time.perf_counter()
    async with AsyncWebCrawler(config=browser_config) as crawler:
        crawl_result = await crawler.arun(url=search_url, config=run_config)
    elapsed_seconds = time.perf_counter() - started_at

    if not crawl_result.success:
        logger.warning(
            "[%s] crawl failed after %.1fs | status=%s error=%s",
            platform.label, elapsed_seconds, crawl_result.status_code, crawl_result.error_message,
        )
        raise PlatformCrawlError(f"{platform.label} crawl failed: {crawl_result.error_message}")

    products = _parse_extracted_products(crawl_result.extracted_content, platform)[:max_items]

    logger.info(
        "[%s] loaded in %.1fs | status=%s | extracted %d product(s)",
        platform.label, elapsed_seconds, crawl_result.status_code, len(products),
    )

    return products
